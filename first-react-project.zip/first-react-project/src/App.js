import React from 'react';
import imageFromSrc from './logo.svg';
import './style.css';

function App() {
  return (
    <div className="App">
      <div style={{border : 'solid 1px black',maxWidh :"100vw" }}>
      <h1 className="Red">My title</h1>
        <br/>
        <img src={imageFromSrc}  alt ='imageFromSrc' />
        <br/>
        <img src='/logo192.png'  alt ='imageFromPublic'  />
        
      </div>
    </div>
  );
}

export default App;
